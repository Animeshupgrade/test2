# Perfectcut – Beauty Salon Website template
#### Preview

 - [Demo](https://themewagon.github.io/perfectcut/)

#### Download
 - [Download from ThemeWagon](https://themewagon.com/themes/perfectcut/)

## Getting Started

1. Clone Repository
```
git clone https://github.com/themewagon/perfectcut.git
```

## Author 
```
Design and code is completely written by Free html Templates and development team. 
```

## License

 - Design and Code is Copyright &copy; [@Free html Templates](https://html.design/)
 - Licensed cover under [MIT]
 - Distributed by [ThemeWagon](https://themewagon.com)

